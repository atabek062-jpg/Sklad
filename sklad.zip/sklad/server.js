// Учёт товаров: Express + SQLite (встроенный node:sqlite, Node 22.5+)
const http = require('http');
const { URL } = require('url');
const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'photos');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new DatabaseSync(path.join(DATA_DIR, 'sklad.db'));
db.exec(`
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  supplier_id INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
  unit TEXT NOT NULL DEFAULT 'шт',
  buy_price REAL NOT NULL DEFAULT 0,
  sell_price REAL NOT NULL DEFAULT 0,
  quantity REAL NOT NULL DEFAULT 0,
  photo TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS stock_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  type TEXT NOT NULL,            -- 'in' приход, 'out' продажа
  qty REAL NOT NULL,
  buy_price REAL NOT NULL DEFAULT 0,
  sell_price REAL NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

// ---------- Поиск: кириллица / латиница / английский ----------
const CYR = {
  а:'a',б:'b',в:'v',г:'g',д:'d',е:'e',ё:'e',ж:'zh',з:'z',и:'i',й:'i',к:'k',л:'l',м:'m',н:'n',
  о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'h',ц:'ts',ч:'ch',ш:'sh',щ:'sh',ъ:'',ы:'i',ь:'',
  э:'e',ю:'u',я:'a',ў:'u',қ:'k',ғ:'g',ҳ:'h'
};
// ключ: слово -> упрощённая латиница, без учёта регистра и различий вроде c/k, w/v, y/i
function phoneticKey(str) {
  let s = String(str || '').toLowerCase();
  s = s.replace(/[а-яёўқғҳ]/g, ch => CYR[ch] ?? '');
  s = s.replace(/ph/g, 'f').replace(/kh/g, 'h').replace(/ck/g, 'k').replace(/ch/g, 'x1')
       .replace(/sh/g, 'x2').replace(/zh/g, 'x3').replace(/ts/g, 'x4')
       .replace(/c(?=[eiy])/g, 's').replace(/c/g, 'k')
       .replace(/q/g, 'k').replace(/w/g, 'v').replace(/[yj]/g, 'i')
       .replace(/x(?![1-4])/g, 'ks')
       .replace(/h/g, '');
  s = s.replace(/[^a-z0-9]/g, '');
  return s.replace(/(.)\1+/g, '$1'); // двойные буквы -> одна
}
function plain(str) { return String(str || '').toLowerCase().trim(); }

function matches(row, q) {
  const qp = plain(q);
  if (!qp) return true;
  const qk = phoneticKey(q);
  const fields = [row.name, row.category_name, row.supplier_name, row.supplier_phone];
  return fields.some(f => {
    const fp = plain(f);
    if (fp.includes(qp)) return true;
    return qk.length >= 2 && phoneticKey(f).includes(qk);
  });
}

// ---------- Вспомогательное ----------
const PRODUCT_SELECT = `
  SELECT p.*, c.name AS category_name, s.name AS supplier_name, s.phone AS supplier_phone
  FROM products p
  LEFT JOIN categories c ON c.id = p.category_id
  LEFT JOIN suppliers s ON s.id = p.supplier_id`;

function withProfit(p) {
  const profit = (p.sell_price || 0) - (p.buy_price || 0);
  return {
    ...p,
    profit_per_unit: round(profit),
    total_buy: round(p.buy_price * p.quantity),
    total_sell: round(p.sell_price * p.quantity),
    total_profit: round(profit * p.quantity)
  };
}
function round(n) { return Math.round(n * 100) / 100; }
function num(v) { const n = Number(String(v ?? '').replace(',', '.')); return Number.isFinite(n) ? n : 0; }

function savePhoto(dataUrl, oldFile) {
  if (!dataUrl) return oldFile || '';
  if (!dataUrl.startsWith('data:image/')) return oldFile || '';
  const m = dataUrl.match(/^data:image\/(png|jpe?g|webp|gif);base64,(.+)$/);
  if (!m) return oldFile || '';
  const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
  const file = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, file), Buffer.from(m[2], 'base64'));
  removePhoto(oldFile);
  return file;
}
function removePhoto(file) {
  if (!file) return;
  const p = path.join(UPLOAD_DIR, path.basename(file));
  fs.promises.unlink(p).catch(() => {});
}

// ---------- Мини-роутер (без внешних зависимостей) ----------
const routes = [];
const app = {
  get: (p, h) => add('GET', p, h), post: (p, h) => add('POST', p, h),
  put: (p, h) => add('PUT', p, h), delete: (p, h) => add('DELETE', p, h)
};
function add(method, pattern, handler) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, handler });
}
const wrap = fn => fn;

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function serveFile(baseDir, rel, res) {
  const file = path.normalize(path.join(baseDir, rel));
  if (!file.startsWith(baseDir)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
    res.end(data);
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > 10 * 1024 * 1024) { reject(new Error('Слишком большой запрос')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(new Error('Неверный JSON')); }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const pathname = decodeURIComponent(url.pathname);
  const json = (data, status = 200) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data)); };
  res.json = json;
  res.status = code => ({ json: d => json(d, code) });

  if (pathname.startsWith('/api/')) {
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = pathname.match(r.re);
      if (!m) continue;
      req.params = {}; r.keys.forEach((k, i) => req.params[k] = m[i + 1]);
      req.query = Object.fromEntries(url.searchParams);
      try {
        req.body = ['POST', 'PUT'].includes(req.method) ? await readBody(req) : {};
        return r.handler(req, res);
      } catch (e) { console.error(e); return json({ error: e.message }, 400); }
    }
    return json({ error: 'Не найдено' }, 404);
  }
  if (pathname.startsWith('/photos/')) return serveFile(UPLOAD_DIR, pathname.slice(8), res);
  return serveFile(path.join(__dirname, 'public'), pathname === '/' ? 'index.html' : pathname.slice(1), res);
});

// ---------- Поставщики ----------
app.get('/api/suppliers', wrap((req, res) => {
  res.json(db.prepare(`
    SELECT s.*, (SELECT COUNT(*) FROM products p WHERE p.supplier_id = s.id) AS products_count
    FROM suppliers s ORDER BY s.name COLLATE NOCASE`).all());
}));
app.post('/api/suppliers', wrap((req, res) => {
  const name = String(req.body.name || '').trim();
  if (!name) throw new Error('Укажите имя поставщика');
  const r = db.prepare('INSERT INTO suppliers (name, phone) VALUES (?, ?)').run(name, String(req.body.phone || '').trim());
  res.json({ id: Number(r.lastInsertRowid) });
}));
app.put('/api/suppliers/:id', wrap((req, res) => {
  const name = String(req.body.name || '').trim();
  if (!name) throw new Error('Укажите имя поставщика');
  db.prepare('UPDATE suppliers SET name = ?, phone = ? WHERE id = ?')
    .run(name, String(req.body.phone || '').trim(), req.params.id);
  res.json({ ok: true });
}));
app.delete('/api/suppliers/:id', wrap((req, res) => {
  db.prepare('DELETE FROM suppliers WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
}));

// ---------- Категории ----------
app.get('/api/categories', wrap((req, res) => {
  res.json(db.prepare(`
    SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS products_count
    FROM categories c ORDER BY c.name COLLATE NOCASE`).all());
}));
app.post('/api/categories', wrap((req, res) => {
  const name = String(req.body.name || '').trim();
  if (!name) throw new Error('Укажите название категории');
  const ex = db.prepare('SELECT id FROM categories WHERE name = ? COLLATE NOCASE').get(name);
  if (ex) return res.json({ id: ex.id });
  const r = db.prepare('INSERT INTO categories (name) VALUES (?)').run(name);
  res.json({ id: Number(r.lastInsertRowid) });
}));
app.put('/api/categories/:id', wrap((req, res) => {
  const name = String(req.body.name || '').trim();
  if (!name) throw new Error('Укажите название категории');
  db.prepare('UPDATE categories SET name = ? WHERE id = ?').run(name, req.params.id);
  res.json({ ok: true });
}));
app.delete('/api/categories/:id', wrap((req, res) => {
  db.prepare('DELETE FROM categories WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
}));

// ---------- Товары ----------
app.get('/api/products', wrap((req, res) => {
  const { q, category_id, supplier_id } = req.query;
  let sql = PRODUCT_SELECT + ' WHERE 1=1';
  const params = [];
  if (category_id) { sql += ' AND p.category_id = ?'; params.push(category_id); }
  if (supplier_id) { sql += ' AND p.supplier_id = ?'; params.push(supplier_id); }
  sql += ' ORDER BY p.name COLLATE NOCASE';
  let rows = db.prepare(sql).all(...params);
  if (q) rows = rows.filter(r => matches(r, q));
  res.json(rows.map(withProfit));
}));

function readProduct(body, existing) {
  const name = String(body.name || '').trim();
  if (!name) throw new Error('Укажите название товара');
  const unit = ['шт', 'кг', 'блок', 'коробка'].includes(body.unit) ? body.unit : 'шт';
  return {
    name, unit,
    category_id: body.category_id ? Number(body.category_id) : null,
    supplier_id: body.supplier_id ? Number(body.supplier_id) : null,
    buy_price: num(body.buy_price),
    sell_price: num(body.sell_price),
    quantity: num(body.quantity),
    photo: body.removePhoto ? (removePhoto(existing?.photo), '') : savePhoto(body.photo, existing?.photo)
  };
}

app.post('/api/products', wrap((req, res) => {
  const p = readProduct(req.body);
  const r = db.prepare(`INSERT INTO products (name, category_id, supplier_id, unit, buy_price, sell_price, quantity, photo)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(p.name, p.category_id, p.supplier_id, p.unit, p.buy_price, p.sell_price, p.quantity, p.photo);
  const id = Number(r.lastInsertRowid);
  if (p.quantity > 0) {
    db.prepare('INSERT INTO stock_movements (product_id, type, qty, buy_price, sell_price) VALUES (?, ?, ?, ?, ?)')
      .run(id, 'in', p.quantity, p.buy_price, p.sell_price);
  }
  res.json({ id });
}));

app.put('/api/products/:id', wrap((req, res) => {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!existing) throw new Error('Товар не найден');
  const p = readProduct(req.body, existing);
  db.prepare(`UPDATE products SET name=?, category_id=?, supplier_id=?, unit=?, buy_price=?, sell_price=?, quantity=?, photo=?
    WHERE id=?`)
    .run(p.name, p.category_id, p.supplier_id, p.unit, p.buy_price, p.sell_price, p.quantity, p.photo, req.params.id);
  res.json({ ok: true });
}));

app.delete('/api/products/:id', wrap((req, res) => {
  const ex = db.prepare('SELECT photo FROM products WHERE id = ?').get(req.params.id);
  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  removePhoto(ex?.photo);
  res.json({ ok: true });
}));

// Приход: добавить количество (при необходимости новая цена прихода / продажи)
app.post('/api/products/:id/arrival', wrap((req, res) => {
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!p) throw new Error('Товар не найден');
  const qty = num(req.body.qty);
  if (qty <= 0) throw new Error('Укажите количество больше нуля');
  const buy = req.body.buy_price !== undefined && req.body.buy_price !== '' ? num(req.body.buy_price) : p.buy_price;
  const sell = req.body.sell_price !== undefined && req.body.sell_price !== '' ? num(req.body.sell_price) : p.sell_price;
  db.prepare('UPDATE products SET quantity = quantity + ?, buy_price = ?, sell_price = ? WHERE id = ?')
    .run(qty, buy, sell, p.id);
  db.prepare('INSERT INTO stock_movements (product_id, type, qty, buy_price, sell_price) VALUES (?, ?, ?, ?, ?)')
    .run(p.id, 'in', qty, buy, sell);
  res.json({ ok: true });
}));

// Продажа: списать количество
app.post('/api/products/:id/sale', wrap((req, res) => {
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!p) throw new Error('Товар не найден');
  const qty = num(req.body.qty);
  if (qty <= 0) throw new Error('Укажите количество больше нуля');
  if (qty > p.quantity) throw new Error(`На складе только ${p.quantity} ${p.unit}`);
  db.prepare('UPDATE products SET quantity = quantity - ? WHERE id = ?').run(qty, p.id);
  db.prepare('INSERT INTO stock_movements (product_id, type, qty, buy_price, sell_price) VALUES (?, ?, ?, ?, ?)')
    .run(p.id, 'out', qty, p.buy_price, p.sell_price);
  res.json({ ok: true });
}));

app.get('/api/products/:id/history', wrap((req, res) => {
  res.json(db.prepare('SELECT * FROM stock_movements WHERE product_id = ? ORDER BY id DESC LIMIT 100').all(req.params.id));
}));

// ---------- Итоги ----------
app.get('/api/summary', wrap((req, res) => {
  const rows = db.prepare('SELECT buy_price, sell_price, quantity FROM products').all();
  let buy = 0, sell = 0;
  for (const r of rows) { buy += r.buy_price * r.quantity; sell += r.sell_price * r.quantity; }
  const sold = db.prepare(`SELECT COALESCE(SUM(qty * sell_price),0) AS revenue,
    COALESCE(SUM(qty * (sell_price - buy_price)),0) AS profit FROM stock_movements WHERE type='out'`).get();
  res.json({
    products: rows.length,
    stock_buy: round(buy), stock_sell: round(sell), stock_profit: round(sell - buy),
    sold_revenue: round(sold.revenue), sold_profit: round(sold.profit)
  });
}));

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Программа запущена: http://localhost:${PORT}`);
  console.log('С телефона (в той же Wi-Fi сети): http://<IP-компьютера>:' + PORT);
});
